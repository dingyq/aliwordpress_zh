<?php
	class CustomComment extends \Timber\Comment {

		public function foo(){
			return 'bar';
		}

	}