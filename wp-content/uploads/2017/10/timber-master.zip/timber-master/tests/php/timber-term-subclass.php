<?php
	class TimberTermSubclass extends TimberTerm {

		public function foo(){
			return 'bar';
		}

	}