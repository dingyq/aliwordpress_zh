## 仿简书主题(个人使用)

------

在新浪云平台上用wordpress搭建了一个个人博客:1.liangtao.sinaapp.com/。自己比较崇尚简洁、宽屏的风格就选择了“简书”主题,自己再做了一些定制化的东西。

## 主题预览
------
### 主页
![index.png](/Jianux/images/index.png "")
------
### 博客页面
![index.png](/Jianux/images/blog.png "")

## 写在最后
主题并不完善,后续会慢慢更新。
